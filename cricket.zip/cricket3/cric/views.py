from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from .models import Blog
from .models import Player
from .models import Team
from .models import Matches
from .models import MatchesTest
from .models import Stadium
from .models import Batsman
from .models import Bowler
from .models import AllRounder
from .models import Rank

# Create your views here.


def index(request):

    return render(request, "index.html")


def login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password1"]
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect("/")
        else:
            messages.info(request, "Invalid Data")
            return redirect("login")
    else:

        return render(request, "login.html")


def register(request):
    if request.method == "POST":
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]
        username = request.POST["username"]
        password1 = request.POST["password1"]
        password2 = request.POST["password2"]
        email = request.POST["email"]
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, "Username Taken")
                return redirect("register")
            elif User.objects.filter(email=email).exists():
                messages.info(request, "Email Taken")
                return redirect("register")
            else:
                user = User.objects.create_user(
                    username=username,
                    password=password1,
                    email=email,
                    first_name=first_name,
                    last_name=last_name,
                )
                user.save()
                return redirect("login")

        else:
            messages.info(request, "Password not matching")
            return redirect("register")
        return redirect("/")

    else:

        return render(request, "register.html")


def logout(request):
    auth.logout(request)
    return redirect("/")


def blog(request):
    if request.method == "POST":
        ti = request.POST["title"]
        d = request.POST["desc"]
        a = request.user
        Blog.objects.create(title=ti, author=a, desc=d)
    else:
        return render(request, "blog.html")
    return redirect("/")


def blogdisplay(request):
    dests = Blog.objects.all()
    a = request.user
    return render(request, "blogdisplay.html", {"dests": dests, "a": a})


def info(request):
    a = 0
    if request.method == "POST":
        name = request.POST["name"]
        dests = Player.objects.all()
        for dest in dests:
            if name == dest.pname:
                a = 1
        if a == 1:
            return render(request, "info.html", {"dests": dests, "name": name})
        else:
            messages.info(request, "Name not found")
            return redirect("info")
    else:
        return render(request, "info2.html")


def team(request):
    a = 0
    if request.method == "POST":
        name = request.POST["name"]
        dests = Team.objects.all()
        for dest in dests:
            if name == dest.tcountry:
                a = 1
        if a == 1:
            return render(request, "team1.html", {"dests": dests, "name": name})
        else:
            messages.info(request, "Name not found")
            return redirect("team")
    else:
        return render(request, "team2.html")


def stadium(request):
    a = 0
    if request.method == "POST":
        name = request.POST["name"]
        dests = Stadium.objects.all()

        for dest in dests:
            if name == dest.stname:
                a = 1
        if a == 1:
            return render(request, "stadium1.html", {"dests": dests, "name": name})
        else:
            messages.info(request, "Name not found")
            return redirect("stadium")
    else:
        return render(request, "stadium2.html")


def matches(request):
    a = 0
    b = 0
    if request.method == "POST":
        t1 = request.POST["team1"]
        t2 = request.POST["team2"]
        fo = request.POST["format"]
        if fo == "Test" or fo == "test" or fo == "TEST":
            dests = MatchesTest.objects.all()
            b = 1
        else:
            dests = Matches.objects.all()

        for dest in dests:

            if t1 == dest.team1:
                if t2 == dest.team2:
                    if fo == dest.mtype:
                        a = 1
        if a == 1:
            return render(
                request,
                "matches1.html",
                {"dests": dests, "t1": t1, "t2": t2, "b": b, "fo": fo},
            )
        else:
            messages.info(request, "Name not found")
            return redirect("matches")
    else:
        return render(request, "matches2.html")


def batrank(request):
    dests = Batsman.objects.all()
    return render(request, "batrank.html", {"dests": dests})


def bowlrank(request):
    dests = Bowler.objects.all()
    return render(request, "bowlrank.html", {"dests": dests})


def allrank(request):
    dests = AllRounder.objects.all()
    return render(request, "allrank.html", {"dests": dests})


def rank(request):
    dests = Rank.objects.all()
    return render(request, "rank.html", {"dests": dests})

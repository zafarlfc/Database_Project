from django.db import models


class Player(models.Model):
    tcountry = models.ForeignKey("Team", models.DO_NOTHING, db_column="tcountry")
    pname = models.CharField(max_length=20, primary_key=True)
    pdob = models.DateField(blank=True, null=True)
    shirtno = models.IntegerField(blank=True, null=True)
    bathand = models.CharField(max_length=10, blank=True, null=True)
    bowlhand = models.CharField(max_length=10, blank=True, null=True)
    specialization = models.CharField(max_length=20)
    odidebut = models.DateField()
    odimatches = models.IntegerField(blank=True, null=True)
    odibatavg = models.FloatField(blank=True, null=True)
    odi100 = models.IntegerField(blank=True, null=True)
    odi50 = models.IntegerField(blank=True, null=True)
    odistrike = models.FloatField(blank=True, null=True)
    odibest = models.IntegerField(blank=True, null=True)
    odiruns = models.IntegerField(blank=True, null=True)
    odiwickets = models.IntegerField(blank=True, null=True)
    odi5w = models.IntegerField(blank=True, null=True)
    odibowlavg = models.FloatField(blank=True, null=True)
    odibestfig = models.CharField(max_length=20, blank=True, null=True)
    odieconomy = models.FloatField(blank=True, null=True)
    odicatches = models.IntegerField(blank=True, null=True)
    odirunouts = models.IntegerField(blank=True, null=True)
    t20debut = models.DateField()
    t20matches = models.IntegerField(blank=True, null=True)
    t20batavg = models.FloatField(blank=True, null=True)
    t20100 = models.IntegerField(blank=True, null=True)
    t2050 = models.IntegerField(blank=True, null=True)
    t20strike = models.FloatField(blank=True, null=True)
    t20best = models.IntegerField(blank=True, null=True)
    t20runs = models.IntegerField(blank=True, null=True)
    t20wickets = models.IntegerField(blank=True, null=True)
    t205w = models.IntegerField(blank=True, null=True)
    t20bowlavg = models.FloatField(blank=True, null=True)
    t20bestfig = models.CharField(max_length=20, blank=True, null=True)
    t20economy = models.FloatField(blank=True, null=True)
    t20catches = models.IntegerField(blank=True, null=True)
    t20runouts = models.IntegerField(blank=True, null=True)
    testdebut = models.DateField()
    testmatches = models.IntegerField(blank=True, null=True)
    testbatavg = models.FloatField(blank=True, null=True)
    test100 = models.IntegerField(blank=True, null=True)
    test50 = models.IntegerField(blank=True, null=True)
    teststrike = models.FloatField(blank=True, null=True)
    testbest = models.IntegerField(blank=True, null=True)
    testruns = models.IntegerField(blank=True, null=True)
    testwickets = models.IntegerField(blank=True, null=True)
    test5w = models.IntegerField(blank=True, null=True)
    test10w = models.IntegerField(blank=True, null=True)
    testbowlavg = models.FloatField(blank=True, null=True)
    testbestfig = models.CharField(max_length=20, blank=True, null=True)
    testeconomy = models.FloatField(blank=True, null=True)
    testcatches = models.IntegerField(blank=True, null=True)
    testrunouts = models.IntegerField(blank=True, null=True)


class Rank(models.Model):
    tcountry = models.ForeignKey("Team", models.DO_NOTHING, db_column="tcountry")
    odirank = models.IntegerField(blank=True, null=True)
    testrank = models.IntegerField(blank=True, null=True)
    t20rank = models.IntegerField(blank=True, null=True)


class AllRounder(models.Model):
    pname = models.ForeignKey("Player", models.DO_NOTHING, db_column="pname")
    odirank = models.IntegerField(blank=True, null=True)
    testrank = models.IntegerField(blank=True, null=True)
    t20rank = models.IntegerField(blank=True, null=True)


class Batsman(models.Model):
    pname = models.ForeignKey("Player", models.DO_NOTHING, db_column="pname")
    odibatrank = models.IntegerField(blank=True, null=True)
    testbatrank = models.IntegerField(blank=True, null=True)
    t20batrank = models.IntegerField(blank=True, null=True)


class Bowler(models.Model):
    pname = models.ForeignKey("Player", models.DO_NOTHING, db_column="pname")
    odibowlrank = models.IntegerField(blank=True, null=True)
    testbowlrank = models.IntegerField(blank=True, null=True)
    t20bowlrank = models.IntegerField(blank=True, null=True)


class Matches(models.Model):
    maid = models.IntegerField(primary_key=True)
    stname = models.ForeignKey(
        "Stadium", models.DO_NOTHING, db_column="stname", blank=False, null=False
    )

    team1 = models.CharField(max_length=20, blank=True, null=True)
    team2 = models.CharField(max_length=20, blank=True, null=True)
    mdate = models.DateField(blank=True, null=True)
    mtype = models.CharField(max_length=20, blank=True, null=True)

    result = models.CharField(max_length=20, blank=True, null=True)
    mom = models.CharField(max_length=20, blank=True, null=True)
    rws1 = models.CharField(max_length=20)
    overs1 = models.FloatField(blank=True, null=True)
    rws2 = models.CharField(max_length=20)
    overs2 = models.FloatField(blank=True, null=True)


class MatchesTest(models.Model):
    maid = models.IntegerField(primary_key=True)
    stname = models.ForeignKey(
        "Stadium", models.DO_NOTHING, db_column="stname", blank=False, null=False
    )
    team1 = models.CharField(max_length=20, blank=True, null=True)
    team2 = models.CharField(max_length=20, blank=True, null=True)
    mdate = models.DateField(blank=True, null=True)
    mtype = models.CharField(max_length=20, blank=True, null=True)
    result = models.CharField(max_length=20, blank=True, null=True)
    mom = models.CharField(max_length=20, blank=True, null=True)
    rws1in1 = models.CharField(max_length=20)
    overs1in1 = models.FloatField(blank=True, null=True)
    rws2in1 = models.CharField(max_length=20)
    overs2in1 = models.FloatField(blank=True, null=True)
    rws1in2 = models.CharField(max_length=20)
    overs1in2 = models.FloatField(blank=True, null=True)
    rws2in2 = models.CharField(max_length=20)
    overs2in2 = models.FloatField(blank=True, null=True)


class Stadium(models.Model):
    stname = models.CharField(max_length=20, primary_key=True)
    scountry = models.CharField(max_length=20, blank=True, null=True)
    capacity = models.IntegerField(blank=True, null=True)
    scity = models.CharField(max_length=20, blank=True, null=True)
    matcheshosted = models.IntegerField(blank=True, null=True)


class Team(models.Model):
    tcountry = models.CharField(max_length=20, primary_key=True)
    captain = models.CharField(max_length=20)
    headcoach = models.CharField(max_length=20)
    batcoach = models.CharField(max_length=20)
    bowlcoach = models.CharField(max_length=20)
    fieldcoach = models.CharField(max_length=20)
    odiplayed = models.IntegerField()
    odiwon = models.IntegerField()
    odilost = models.IntegerField()
    oditied = models.IntegerField(blank=True, null=True)
    odihighest = models.IntegerField(blank=True, null=True)
    odilowest = models.IntegerField(blank=True, null=True)
    odiwinper = models.FloatField(blank=True, null=True)
    t20played = models.IntegerField()
    t20won = models.IntegerField()
    t20lost = models.IntegerField()
    t20tied = models.IntegerField(blank=True, null=True)
    t20highest = models.IntegerField(blank=True, null=True)
    t20lowest = models.IntegerField(blank=True, null=True)
    t20winper = models.FloatField(blank=True, null=True)
    testplayed = models.IntegerField()
    testwon = models.IntegerField()
    testlost = models.IntegerField()
    testdraw = models.IntegerField(blank=True, null=True)
    testhighest = models.IntegerField(blank=True, null=True)
    testlowest = models.IntegerField(blank=True, null=True)
    testwinper = models.FloatField(blank=True, null=True)


class Blog(models.Model):
    title = models.TextField()
    author = models.CharField(max_length=100)
    desc = models.TextField()

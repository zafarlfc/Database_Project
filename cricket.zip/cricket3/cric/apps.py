from django.apps import AppConfig


class CricConfig(AppConfig):
    name = 'cric'

from django.contrib import admin
from .models import (
    Player,
    Team,
    Matches,
    AllRounder,
    Batsman,
    Bowler,
    MatchesTest,
    Stadium,
    Rank,
)
from .models import Blog

# Register your models here.

admin.site.register(Player)
admin.site.register(Batsman)
admin.site.register(Bowler)
admin.site.register(AllRounder)
admin.site.register(Team)
admin.site.register(Blog)
admin.site.register(Stadium)
admin.site.register(MatchesTest)
admin.site.register(Matches)
admin.site.register(Rank)
